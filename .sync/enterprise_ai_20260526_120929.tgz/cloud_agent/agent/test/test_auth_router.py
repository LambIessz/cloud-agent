import sys
from pathlib import Path

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient


APP_DIR = Path(__file__).resolve().parents[2] / "app"
AGENT_DIR = Path(__file__).resolve().parents[1]
for path in (APP_DIR, AGENT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from router import chat as chat_router
from security.auth import resolve_authenticated_identity


def _test_app() -> FastAPI:
    app = FastAPI()
    app.include_router(chat_router.router, prefix="/api")
    return app


def test_production_auth_requires_gateway_authenticated_user_header(monkeypatch):
    monkeypatch.setenv("CLOUD_AGENT_AUTH_MODE", "production")

    with pytest.raises(HTTPException) as exc_info:
        resolve_authenticated_identity(
            {},
            debug_user_id="debug_user",
            debug_tenant_id="debug_tenant",
        )

    assert exc_info.value.status_code == 401
    assert exc_info.value.detail == "authentication_required"
    assert "debug_user" not in str(exc_info.value.detail)


def test_production_auth_uses_configurable_gateway_headers(monkeypatch):
    monkeypatch.setenv("CLOUD_AGENT_AUTH_MODE", "production")
    monkeypatch.setenv("CLOUD_AGENT_AUTH_USER_HEADER", "X-Auth-User")
    monkeypatch.setenv("CLOUD_AGENT_AUTH_TENANT_HEADER", "X-Auth-Tenant")

    identity = resolve_authenticated_identity(
        {
            "X-Auth-User": " authenticated_user ",
            "X-Auth-Tenant": " authenticated_tenant ",
            "X-User-Id": "debug_user",
            "X-Tenant-Id": "debug_tenant",
        }
    )

    assert identity.user_id == "authenticated_user"
    assert identity.tenant_id == "authenticated_tenant"


def test_chat_endpoint_production_rejects_missing_authenticated_header(monkeypatch):
    monkeypatch.setenv("CLOUD_AGENT_AUTH_MODE", "production")
    client = TestClient(_test_app())

    response = client.post(
        "/api/chat",
        json={
            "query": "hello",
            "user_id": "body_user",
            "tenant_id": "body_tenant",
            "session_id": "session_1",
        },
    )

    assert response.status_code == 401
    assert response.json() == {"detail": "authentication_required"}
    assert "body_user" not in response.text
    assert "body_tenant" not in response.text


def test_chat_endpoint_production_passes_authenticated_identity_only(monkeypatch):
    monkeypatch.setenv("CLOUD_AGENT_AUTH_MODE", "production")
    captured = {}

    async def _fake_stream_chat(
        query,
        user_id,
        session_id,
        *,
        request_id,
        request_tenant_id,
        authenticated_user_id,
        authenticated_tenant_id,
    ):
        captured.update(
            {
                "query": query,
                "user_id": user_id,
                "session_id": session_id,
                "request_id": request_id,
                "request_tenant_id": request_tenant_id,
                "authenticated_user_id": authenticated_user_id,
                "authenticated_tenant_id": authenticated_tenant_id,
            }
        )
        yield 'data: {"done": true}\n\n'

    monkeypatch.setattr(chat_router, "stream_chat", _fake_stream_chat)
    client = TestClient(_test_app())

    response = client.post(
        "/api/chat",
        headers={
            "X-Authenticated-User-Id": "auth_user",
            "X-Authenticated-Tenant-Id": "auth_tenant",
            "X-User-Id": "debug_user",
            "X-Tenant-Id": "debug_tenant",
        },
        json={
            "query": "hello",
            "user_id": "body_user",
            "tenant_id": "body_tenant",
            "session_id": "session_1",
        },
    )

    assert response.status_code == 200
    assert captured["user_id"] == "body_user"
    assert captured["request_tenant_id"] == "body_tenant"
    assert captured["authenticated_user_id"] == "auth_user"
    assert captured["authenticated_tenant_id"] == "auth_tenant"
    assert captured["request_id"].startswith("req_")
    assert "body_user" not in response.text
    assert "auth_user" not in response.text


def test_chat_endpoint_local_mode_keeps_existing_debug_header_behavior(monkeypatch):
    monkeypatch.setenv("CLOUD_AGENT_AUTH_MODE", "local")
    captured = {}

    async def _fake_stream_chat(
        query,
        user_id,
        session_id,
        *,
        request_id,
        request_tenant_id,
        authenticated_user_id,
        authenticated_tenant_id,
    ):
        captured.update(
            {
                "user_id": user_id,
                "request_tenant_id": request_tenant_id,
                "authenticated_user_id": authenticated_user_id,
                "authenticated_tenant_id": authenticated_tenant_id,
            }
        )
        yield 'data: {"done": true}\n\n'

    monkeypatch.setattr(chat_router, "stream_chat", _fake_stream_chat)
    client = TestClient(_test_app())

    response = client.post(
        "/api/chat",
        headers={
            "X-User-Id": "debug_user",
            "X-Tenant-Id": "debug_tenant",
        },
        json={
            "query": "hello",
            "user_id": "body_user",
            "tenant_id": "body_tenant",
            "session_id": "session_1",
        },
    )

    assert response.status_code == 200
    assert captured["user_id"] == "body_user"
    assert captured["request_tenant_id"] == "body_tenant"
    assert captured["authenticated_user_id"] == "debug_user"
    assert captured["authenticated_tenant_id"] == "debug_tenant"
