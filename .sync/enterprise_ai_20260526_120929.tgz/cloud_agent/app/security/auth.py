import os
from dataclasses import dataclass
from typing import Mapping

from fastapi import HTTPException, Request, status


DEFAULT_AUTH_USER_HEADER = "X-Authenticated-User-Id"
DEFAULT_AUTH_TENANT_HEADER = "X-Authenticated-Tenant-Id"


@dataclass(frozen=True)
class AuthenticatedIdentity:
    user_id: str | None = None
    tenant_id: str | None = None


def _auth_mode() -> str:
    return os.getenv("CLOUD_AGENT_AUTH_MODE", "local").strip().lower()


def _env_header(name: str, default: str) -> str:
    value = os.getenv(name, default).strip()
    return value or default


def _clean_header_value(value: str | None) -> str | None:
    cleaned = (value or "").strip()
    return cleaned or None


def _is_production_mode() -> bool:
    return _auth_mode() in {"prod", "production"}


def resolve_authenticated_identity(
    headers: Mapping[str, str],
    *,
    debug_user_id: str | None = None,
    debug_tenant_id: str | None = None,
) -> AuthenticatedIdentity:
    """
    Resolve trusted identity at the HTTP boundary.

    Local mode keeps existing demo behavior: X-User-Id / X-Tenant-Id can be
    used as a debug authenticated identity, and request body user_id remains
    accepted downstream when these headers are absent.

    Production mode only trusts explicit gateway-authenticated headers. The
    request body user_id and debug headers are ignored by design.
    """
    if not _is_production_mode():
        return AuthenticatedIdentity(
            user_id=_clean_header_value(debug_user_id),
            tenant_id=_clean_header_value(debug_tenant_id),
        )

    user_header = _env_header("CLOUD_AGENT_AUTH_USER_HEADER", DEFAULT_AUTH_USER_HEADER)
    tenant_header = _env_header("CLOUD_AGENT_AUTH_TENANT_HEADER", DEFAULT_AUTH_TENANT_HEADER)

    authenticated_user_id = _clean_header_value(headers.get(user_header))
    if authenticated_user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="authentication_required",
        )

    return AuthenticatedIdentity(
        user_id=authenticated_user_id,
        tenant_id=_clean_header_value(headers.get(tenant_header)),
    )


def resolve_authenticated_identity_from_request(
    request: Request,
    *,
    debug_user_id: str | None = None,
    debug_tenant_id: str | None = None,
) -> AuthenticatedIdentity:
    return resolve_authenticated_identity(
        request.headers,
        debug_user_id=debug_user_id,
        debug_tenant_id=debug_tenant_id,
    )
